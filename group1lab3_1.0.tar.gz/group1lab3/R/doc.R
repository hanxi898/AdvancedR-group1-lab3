#' @title group1lab3
#' @description This package covers two functions -- "euclidean" and "dijkstra".
#' @details "Euclidean" function computes the greatest common divisor of two numbers. And "dijkstra" function computes the shortest paths from a given starting node to all other nodes in a graph.
#' @name doc-package
NULL

